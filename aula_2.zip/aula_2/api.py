from flask import Flask, jsonify, request, render_template_string, redirect, url_for, flash, session
from decimal import Decimal, InvalidOperation

app = Flask(__name__)
app.secret_key = "sua_chave_secreta_aqui"

# =========================
# Banco fake de usuários
# =========================
usuarios = []

# =========================
# Banco fake de produtos
# =========================
produtos = [
    {"id": 1, "nome": "Camiseta", "preco": 50.00},
    {"id": 2, "nome": "Tênis", "preco": 120.00},
    {"id": 3, "nome": "Boné", "preco": 35.00}
]


# =========================
# Funções
# =========================
def gerar_novo_id():
    if not produtos:
        return 1
    return max(p["id"] for p in produtos) + 1


def buscar_produto(produto_id):
    return next((p for p in produtos if p["id"] == produto_id), None)


def formatar_preco(valor):
    return f"{valor:.2f}".replace(".", ",")


def usuario_logado():
    return "usuario" in session


# =========================
# HTML LOGIN
# =========================
HTML_LOGIN = """
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Login</title>

<style>
body{
    background:#0f172a;
    font-family:Arial;
    color:white;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

.box{
    background:#1e293b;
    padding:30px;
    border-radius:15px;
    width:350px;
}

input{
    width:100%;
    padding:12px;
    margin-top:10px;
    border:none;
    border-radius:8px;
}

button{
    width:100%;
    padding:12px;
    margin-top:15px;
    border:none;
    border-radius:8px;
    background:#2563eb;
    color:white;
    font-weight:bold;
    cursor:pointer;
}

button:hover{
    background:#1d4ed8;
}

a{
    color:#60a5fa;
}

.msg{
    background:#22c55e;
    padding:10px;
    border-radius:8px;
    margin-bottom:10px;
}
</style>
</head>
<body>

<div class="box">

<h1>🔐 Login</h1>

{% with messages = get_flashed_messages() %}
    {% if messages %}
        {% for msg in messages %}
            <div class="msg">{{ msg }}</div>
        {% endfor %}
    {% endif %}
{% endwith %}

<form method="POST">

<input type="text" name="nome" placeholder="Digite seu nome" required>

<input type="password" name="senha" placeholder="Digite sua senha" required>

<button type="submit">Entrar</button>

</form>

<p style="margin-top:15px;">
Não tem conta?
<a href="/criar-conta">Criar conta</a>
</p>

</div>

</body>
</html>
"""


# =========================
# HTML CRIAR CONTA
# =========================
HTML_CADASTRO = """
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Criar Conta</title>

<style>
body{
    background:#0f172a;
    font-family:Arial;
    color:white;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

.box{
    background:#1e293b;
    padding:30px;
    border-radius:15px;
    width:350px;
}

input{
    width:100%;
    padding:12px;
    margin-top:10px;
    border:none;
    border-radius:8px;
}

button{
    width:100%;
    padding:12px;
    margin-top:15px;
    border:none;
    border-radius:8px;
    background:#16a34a;
    color:white;
    font-weight:bold;
    cursor:pointer;
}

button:hover{
    background:#15803d;
}

a{
    color:#60a5fa;
}
</style>
</head>
<body>

<div class="box">

<h1>📝 Criar Conta</h1>

<form method="POST">

<input type="text" name="nome" placeholder="Nome" required>

<input type="password" name="senha" placeholder="Senha" required>

<button type="submit">Criar Conta</button>

</form>

<p style="margin-top:15px;">
Já possui conta?
<a href="/login">Entrar</a>
</p>

</div>

</body>
</html>
"""


# =========================
# HTML LOJA
# =========================
HTML = """
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Loja</title>

<style>

body{
    font-family:Arial;
    background:#0f172a;
    color:white;
    padding:20px;
}

.container{
    max-width:1000px;
    margin:auto;
}

.topo{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:20px;
}

.card{
    background:#1e293b;
    padding:20px;
    border-radius:12px;
    margin-bottom:15px;
}

button{
    padding:10px;
    border:none;
    border-radius:8px;
    cursor:pointer;
}

.add{
    background:#2563eb;
    color:white;
}

.delete{
    background:#dc2626;
    color:white;
}

.edit{
    background:#16a34a;
    color:white;
}

input{
    padding:10px;
    border:none;
    border-radius:8px;
    margin-top:5px;
}

.msg{
    background:#22c55e;
    padding:10px;
    border-radius:8px;
    margin-bottom:10px;
}

</style>
</head>
<body>

<div class="container">

<div class="topo">
    <div>
        <h1>🛒 Loja Virtual</h1>

        <h3>
        Olá {{ usuario }},
        estamos entrando na conta!
        </h3>
    </div>

    <a href="/logout">
        <button class="delete">Sair</button>
    </a>
</div>

{% with messages = get_flashed_messages() %}
    {% if messages %}
        {% for msg in messages %}
            <div class="msg">{{ msg }}</div>
        {% endfor %}
    {% endif %}
{% endwith %}

<form action="/adicionar" method="POST">

<input type="text" name="nome" placeholder="Nome do produto" required>

<input type="number" step="0.01" name="preco" placeholder="Preço" required>

<button class="add" type="submit">
Adicionar Produto
</button>

</form>

<hr><br>

{% for produto in produtos %}

<div class="card">

<h2>{{ produto.nome }}</h2>

<h3>R$ {{ produto.preco_formatado }}</h3>

<form action="/deletar/{{ produto.id }}" method="POST">

<button class="delete">
Excluir
</button>

</form>

<br>

<form action="/editar/{{ produto.id }}" method="POST">

<input type="text" name="nome" placeholder="Novo nome" required>

<input type="number" step="0.01" name="preco" placeholder="Novo preço" required>

<button class="edit">
Editar
</button>

</form>

</div>

{% endfor %}

</div>

</body>
</html>
"""


# =========================
# LOGIN
# =========================
@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        nome = request.form["nome"]
        senha = request.form["senha"]

        usuario = next(
            (
                u for u in usuarios
                if u["nome"] == nome and u["senha"] == senha
            ),
            None
        )

        if usuario:
            session["usuario"] = nome
            flash("Login realizado com sucesso!")
            return redirect(url_for("home"))

        flash("Usuário ou senha incorretos!")

    return render_template_string(HTML_LOGIN)


# =========================
# CRIAR CONTA
# =========================
@app.route("/criar-conta", methods=["GET", "POST"])
def criar_conta():

    if request.method == "POST":

        nome = request.form["nome"]
        senha = request.form["senha"]

        existe = next(
            (u for u in usuarios if u["nome"] == nome),
            None
        )

        if existe:
            flash("Usuário já existe!")
            return redirect(url_for("criar_conta"))

        usuarios.append({
            "nome": nome,
            "senha": senha
        })

        flash("Conta criada com sucesso!")
        return redirect(url_for("login"))

    return render_template_string(HTML_CADASTRO)


# =========================
# LOGOUT
# =========================
@app.route("/logout")
def logout():
    session.clear()
    flash("Você saiu da conta.")
    return redirect(url_for("login"))


# =========================
# HOME
# =========================
@app.route("/")
def home():

    if not usuario_logado():
        return redirect(url_for("login"))

    produtos_exibicao = [
        {
            **produto,
            "preco_formatado": formatar_preco(produto["preco"])
        }
        for produto in produtos
    ]

    return render_template_string(
        HTML,
        produtos=produtos_exibicao,
        usuario=session["usuario"]
    )


# =========================
# ADICIONAR
# =========================
@app.route("/adicionar", methods=["POST"])
def adicionar():

    nome = request.form.get("nome", "").strip()
    preco_raw = request.form.get("preco", "").strip()

    try:
        preco = float(Decimal(preco_raw))

    except (InvalidOperation, ValueError):
        flash("Preço inválido.")
        return redirect(url_for("home"))

    produtos.append({
        "id": gerar_novo_id(),
        "nome": nome,
        "preco": preco
    })

    flash("Produto adicionado!")

    return redirect(url_for("home"))


# =========================
# DELETAR
# =========================
@app.route("/deletar/<int:id>", methods=["POST"])
def deletar(id):

    produto = buscar_produto(id)

    if produto:
        produtos.remove(produto)
        flash("Produto removido!")

    return redirect(url_for("home"))


# =========================
# EDITAR
# =========================
@app.route("/editar/<int:id>", methods=["POST"])
def editar(id):

    produto = buscar_produto(id)

    if produto:

        nome = request.form["nome"]

        preco = float(request.form["preco"])

        produto["nome"] = nome
        produto["preco"] = preco

        flash("Produto atualizado!")

    return redirect(url_for("home"))


# =========================
# API GET
# =========================
@app.route("/produtos", methods=["GET"])
def listar_produtos():
    return jsonify(produtos)


# =========================
# API POST
# =========================
@app.route("/produtos", methods=["POST"])
def api_post():

    dados = request.get_json()

    novo_produto = {
        "id": gerar_novo_id(),
        "nome": dados["nome"],
        "preco": dados["preco"]
    }

    produtos.append(novo_produto)

    return jsonify(novo_produto), 201


# =========================
# RODAR
# =========================
if __name__ == "__main__":
    app.run(debug=True)